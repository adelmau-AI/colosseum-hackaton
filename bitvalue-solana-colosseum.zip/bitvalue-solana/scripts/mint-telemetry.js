/**
 * mint-telemetry.js
 * --------------------------------------------------------------------------
 * Mints BVC and attaches an on-chain memo that cryptographically links the
 * reward to a real JT808 telemetry packet.
 *
 * Privacy design
 * --------------
 * - IMEI is never written to the chain. Only a short salted hash (dev=) is used.
 * - The packet itself is represented by its SHA-256 (pkt=). Location / sensor
 *   data never leaves the server.
 * - Full proof (IMEI + full packet hash + signature) is appended to proofs.jsonl
 *   on the server for internal audit / dispute resolution.
 *
 * Memo format (human-readable, fits in Solana memo program):
 *   bitvalue:v1 dev=<16hex> pkt=<32hex> bytes=<n> ts=<unix>
 *
 * Usage:
 *   node scripts/mint-telemetry.js <IMEI> <TRAMA_HEX> [wallet|test] [amount]
 *
 * Examples:
 *   node scripts/mint-telemetry.js 069251600273 "7e0200...7e" test 0.1
 *   node scripts/mint-telemetry.js 069251600273 7e0200...7e <DRIVER_WALLET> 0.25
 */

import 'dotenv/config';
import fs from 'fs';
import crypto from 'crypto';
import {
  Connection,
  Keypair,
  PublicKey,
  Transaction,
  TransactionInstruction,
  sendAndConfirmTransaction,
} from '@solana/web3.js';
import {
  TOKEN_2022_PROGRAM_ID,
  getAssociatedTokenAddressSync,
  createAssociatedTokenAccountIdempotentInstruction,
  createMintToInstruction,
} from '@solana/spl-token';

// ---------------------------------------------------------------------------
// CLI arguments
// ---------------------------------------------------------------------------
const [,, imei, hex, recipientArg, amountArg] = process.argv;

if (!imei || !hex) {
  console.error(
    'Usage: node scripts/mint-telemetry.js <IMEI> <TRAMA_HEX> [wallet|test] [BVC]'
  );
  process.exit(1);
}

if (!process.env.MINT_ADDRESS) {
  console.error('MINT_ADDRESS is not set. Run create-token.js first.');
  process.exit(1);
}

if (!process.env.DEVICE_SALT) {
  console.error(
    'DEVICE_SALT is not set. Generate one with:\n  openssl rand -hex 32\nand add it to .env'
  );
  process.exit(1);
}

// ---------------------------------------------------------------------------
// Packet fingerprinting
// ---------------------------------------------------------------------------
const raw = Buffer.from(hex.replace(/\s+/g, ''), 'hex');
if (raw.length === 0) {
  console.error('Invalid hex packet');
  process.exit(1);
}

const sha256 = (buf) => crypto.createHash('sha256').update(buf).digest('hex');

// Short device fingerprint (salted IMEI) — never the raw IMEI
const dev = sha256(process.env.DEVICE_SALT + imei).slice(0, 16);

// Full packet hash (first 32 chars go on-chain to keep memo compact)
const pktFull = sha256(raw);
const ts = Math.floor(Date.now() / 1000);

const memo = `bitvalue:v1 dev=${dev} pkt=${pktFull.slice(0, 32)} bytes=${raw.length} ts=${ts}`;

// ---------------------------------------------------------------------------
// Resolve recipient & amount
// ---------------------------------------------------------------------------
const DECIMALS = 6;
const conn = new Connection(process.env.RPC_URL, 'confirmed');
const auth = Keypair.fromSecretKey(
  Uint8Array.from(JSON.parse(fs.readFileSync(process.env.AUTHORITY_KEYPAIR, 'utf8')))
);
const mint = new PublicKey(process.env.MINT_ADDRESS);

let recipient = recipientArg;
if (!recipient || recipient === 'test') {
  const testKeyPath = './keys/driver-test.json';
  if (!fs.existsSync(testKeyPath)) {
    fs.writeFileSync(
      testKeyPath,
      JSON.stringify(Array.from(Keypair.generate().secretKey)),
      { mode: 0o600 }
    );
  }
  recipient = Keypair.fromSecretKey(
    Uint8Array.from(JSON.parse(fs.readFileSync(testKeyPath, 'utf8')))
  ).publicKey.toBase58();
}

const owner = new PublicKey(recipient);
const amount = BigInt(
  Math.round(parseFloat(amountArg || '0.1') * 10 ** DECIMALS)
);

const ata = getAssociatedTokenAddressSync(
  mint,
  owner,
  false,
  TOKEN_2022_PROGRAM_ID
);

// ---------------------------------------------------------------------------
// Single atomic transaction:
// 1. Create ATA if missing (idempotent)
// 2. Mint the reward
// 3. Attach the telemetry memo
// ---------------------------------------------------------------------------
const tx = new Transaction().add(
  createAssociatedTokenAccountIdempotentInstruction(
    auth.publicKey,
    ata,
    owner,
    mint,
    TOKEN_2022_PROGRAM_ID
  ),
  createMintToInstruction(
    mint,
    ata,
    auth.publicKey,
    amount,
    [],
    TOKEN_2022_PROGRAM_ID
  ),
  // Solana Memo program — public, permanent, searchable
  new TransactionInstruction({
    keys: [{ pubkey: auth.publicKey, isSigner: true, isWritable: false }],
    programId: new PublicKey('MemoSq4gqABAXKb96qnH8TysNcWxMyWCqXgDLGmfcHr'),
    data: Buffer.from(memo, 'utf8'),
  })
);

const sig = await sendAndConfirmTransaction(conn, tx, [auth]);

// ---------------------------------------------------------------------------
// Internal audit log (never goes on-chain)
// ---------------------------------------------------------------------------
const proof = {
  ts,
  imei,
  dev,
  pkt: pktFull,
  bytes: raw.length,
  recipient,
  bvc: Number(amount) / 10 ** DECIMALS,
  sig,
};

fs.appendFileSync('proofs.jsonl', JSON.stringify(proof) + '\n', { mode: 0o600 });

console.log('Memo     :', memo);
console.log('Minted   :', Number(amount) / 10 ** DECIMALS, 'BVC →', recipient);
console.log(`Explorer : https://explorer.solana.com/tx/${sig}?cluster=devnet`);
console.log('Proof appended to proofs.jsonl (server-side only).');
