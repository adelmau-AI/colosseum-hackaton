/**
 * set-uri.js
 * --------------------------------------------------------------------------
 * Updates the on-chain metadata URI of the BVC mint so explorers and wallets
 * can fetch the off-chain JSON (name, symbol, description, image).
 *
 * The off-chain JSON must already be publicly reachable, e.g.:
 *   https://bitvalue-coin.com/token/bvc.json
 *
 * Example JSON content:
 * {
 *   "name": "BitValue Coin",
 *   "symbol": "BVC",
 *   "description": "Reward token for verified vehicle telemetry on the BitValue DePIN network. Devnet deployment.",
 *   "image": "https://bitvalue-coin.com/bitvalue-icon.png",
 *   "external_url": "https://bitvalue-coin.com"
 * }
 *
 * CORS header required on the hosting folder:
 *   Header set Access-Control-Allow-Origin "*"
 *
 * Usage:
 *   npm run set-uri -- https://bitvalue-coin.com/token/bvc.json
 *   node scripts/set-uri.js https://bitvalue-coin.com/token/bvc.json
 */

import 'dotenv/config';
import fs from 'fs';
import {
  Connection,
  Keypair,
  PublicKey,
  SystemProgram,
  Transaction,
  sendAndConfirmTransaction,
} from '@solana/web3.js';
import {
  TOKEN_2022_PROGRAM_ID,
  getTokenMetadata,
} from '@solana/spl-token';
import {
  createUpdateFieldInstruction,
  pack,
} from '@solana/spl-token-metadata';

const URI = process.argv[2];
if (!URI) {
  console.error('Usage: node scripts/set-uri.js <url-of-metadata-json>');
  process.exit(1);
}

if (!process.env.MINT_ADDRESS) {
  console.error('MINT_ADDRESS is not set. Run create-token.js first.');
  process.exit(1);
}

const conn = new Connection(process.env.RPC_URL, 'confirmed');
const auth = Keypair.fromSecretKey(
  Uint8Array.from(JSON.parse(fs.readFileSync(process.env.AUTHORITY_KEYPAIR, 'utf8')))
);
const mint = new PublicKey(process.env.MINT_ADDRESS);

// Read current on-chain metadata to calculate the size difference
const meta = await getTokenMetadata(conn, mint, 'confirmed', TOKEN_2022_PROGRAM_ID);
const info = await conn.getAccountInfo(mint);

// Extra rent that may be needed when the URI field grows
const extra = pack({ ...meta, uri: URI }).length - pack(meta).length;
const need = await conn.getMinimumBalanceForRentExemption(
  info.data.length + Math.max(extra, 0)
);

const tx = new Transaction();

// Top-up rent if the account is not large enough after the URI update
if (need > info.lamports) {
  tx.add(
    SystemProgram.transfer({
      fromPubkey: auth.publicKey,
      toPubkey: mint,
      lamports: need - info.lamports,
    })
  );
}

// Update the uri field
tx.add(
  createUpdateFieldInstruction({
    programId: TOKEN_2022_PROGRAM_ID,
    metadata: mint,
    updateAuthority: auth.publicKey,
    field: 'uri',
    value: URI,
  })
);

const sig = await sendAndConfirmTransaction(conn, tx, [auth]);

console.log('URI updated successfully.');
console.log('New URI  :', URI);
console.log('Tx       :', sig);
console.log(
  `Explorer : https://explorer.solana.com/address/${mint.toBase58()}?cluster=devnet`
);
console.log('');
console.log('Note: logo may take a few minutes to appear due to explorer caching.');
