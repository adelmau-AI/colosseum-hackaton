/**
 * keygen.js
 * --------------------------------------------------------------------------
 * Generates (or reports) the mint-authority keypair for BitValue Coin (BVC).
 *
 * - Writes the secret key as a JSON array of bytes to AUTHORITY_KEYPAIR path.
 * - File permissions are set to 0600 (owner read/write only).
 * - Safe to re-run: if the file already exists it only prints the public key.
 *
 * Usage:
 *   npm run keygen
 *   node scripts/keygen.js
 *
 * IMPORTANT
 * ---------
 * On mainnet this file becomes the single mint authority.
 * Back it up offline and eventually move to a multisig / hardware wallet.
 */

import 'dotenv/config';
import fs from 'fs';
import { Keypair } from '@solana/web3.js';

const path = process.env.AUTHORITY_KEYPAIR;

if (!path) {
  console.error('AUTHORITY_KEYPAIR is not set in .env');
  process.exit(1);
}

// Ensure keys directory exists
const dir = path.substring(0, path.lastIndexOf('/')) || '.';
if (!fs.existsSync(dir)) {
  fs.mkdirSync(dir, { recursive: true, mode: 0o700 });
}

if (fs.existsSync(path)) {
  const kp = Keypair.fromSecretKey(
    Uint8Array.from(JSON.parse(fs.readFileSync(path, 'utf8')))
  );
  console.log('Keypair already exists.');
  console.log('Public key (mint authority):', kp.publicKey.toBase58());
  process.exit(0);
}

const kp = Keypair.generate();
fs.writeFileSync(path, JSON.stringify(Array.from(kp.secretKey)), {
  mode: 0o600,
});

console.log('New mint-authority keypair created.');
console.log('Public key:', kp.publicKey.toBase58());
console.log('Secret key saved to:', path);
console.log('→ Keep this file offline and never commit it to git.');
