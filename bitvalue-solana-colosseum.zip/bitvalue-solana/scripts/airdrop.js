/**
 * airdrop.js
 * --------------------------------------------------------------------------
 * Requests 1 SOL of devnet airdrop for the mint-authority wallet.
 *
 * Note: Public RPC faucets often reject requests coming from datacenter IPs
 * (DigitalOcean, AWS, etc.). If it fails with "Internal error", request SOL
 * manually from https://faucet.solana.com (select Devnet) and then run
 * `npm run balance` to verify.
 *
 * Usage:
 *   npm run airdrop
 *   node scripts/airdrop.js
 */

import 'dotenv/config';
import fs from 'fs';
import {
  Connection,
  Keypair,
  LAMPORTS_PER_SOL,
} from '@solana/web3.js';

const conn = new Connection(process.env.RPC_URL, 'confirmed');
const kp = Keypair.fromSecretKey(
  Uint8Array.from(JSON.parse(fs.readFileSync(process.env.AUTHORITY_KEYPAIR, 'utf8')))
);
const pk = kp.publicKey;

try {
  const sig = await conn.requestAirdrop(pk, 1 * LAMPORTS_PER_SOL);
  const latest = await conn.getLatestBlockhash();
  await conn.confirmTransaction({ signature: sig, ...latest }, 'confirmed');
  console.log('Airdrop successful.');
  console.log('Signature:', sig);
} catch (err) {
  console.log('Airdrop failed:', err.message);
  console.log('');
  console.log('This is common on public RPCs from cloud IPs.');
  console.log('→ Go to https://faucet.solana.com');
  console.log('→ Paste address:', pk.toBase58());
  console.log('→ Select Devnet and request 1–2 SOL');
}

console.log('Address :', pk.toBase58());
console.log('Balance :', (await conn.getBalance(pk)) / LAMPORTS_PER_SOL, 'SOL');
