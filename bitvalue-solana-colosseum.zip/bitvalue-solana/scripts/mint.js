/**
 * mint.js
 * --------------------------------------------------------------------------
 * Simple mint of BVC to any wallet (or a local test driver wallet).
 *
 * - Creates the Associated Token Account (ATA) if it does not exist.
 * - The authority pays the rent for the ATA the first time (~0.002 SOL).
 * - Subsequent mints to the same wallet only cost the network fee.
 *
 * Usage:
 *   npm run mint -- test 10          # 10 BVC to local test driver
 *   npm run mint -- <WALLET> 5.5     # 5.5 BVC to a specific address
 *   node scripts/mint.js test 10
 *   node scripts/mint.js <WALLET> 1
 */

import 'dotenv/config';
import fs from 'fs';
import { Connection, Keypair, PublicKey } from '@solana/web3.js';
import {
  TOKEN_2022_PROGRAM_ID,
  getOrCreateAssociatedTokenAccount,
  mintTo,
} from '@solana/spl-token';

const DECIMALS = 6;

if (!process.env.MINT_ADDRESS) {
  console.error('MINT_ADDRESS is not set. Run create-token.js first.');
  process.exit(1);
}

const conn = new Connection(process.env.RPC_URL, 'confirmed');
const auth = Keypair.fromSecretKey(
  Uint8Array.from(JSON.parse(fs.readFileSync(process.env.AUTHORITY_KEYPAIR, 'utf8')))
);
const mint = new PublicKey(process.env.MINT_ADDRESS);

// ---------------------------------------------------------------------------
// Resolve recipient
// ---------------------------------------------------------------------------
let recipient = process.argv[2];

if (!recipient || recipient === 'test') {
  const testKeyPath = './keys/driver-test.json';
  if (!fs.existsSync(testKeyPath)) {
    // Create a disposable test driver wallet on first use
    fs.writeFileSync(
      testKeyPath,
      JSON.stringify(Array.from(Keypair.generate().secretKey)),
      { mode: 0o600 }
    );
  }
  recipient = Keypair.fromSecretKey(
    Uint8Array.from(JSON.parse(fs.readFileSync(testKeyPath, 'utf8')))
  ).publicKey.toBase58();
}

const owner = new PublicKey(recipient);
const amount = BigInt(
  Math.round(parseFloat(process.argv[3] || '1') * 10 ** DECIMALS)
);

// ---------------------------------------------------------------------------
// Create ATA (if needed) + mint
// ---------------------------------------------------------------------------
const ata = await getOrCreateAssociatedTokenAccount(
  conn,
  auth,                 // payer
  mint,
  owner,
  false,                // allowOwnerOffCurve
  'confirmed',
  undefined,
  TOKEN_2022_PROGRAM_ID
);

const sig = await mintTo(
  conn,
  auth,                 // payer / fee payer
  mint,
  ata.address,
  auth,                 // mint authority
  amount,
  [],
  undefined,
  TOKEN_2022_PROGRAM_ID
);

console.log('Recipient :', owner.toBase58());
console.log('Minted    :', Number(amount) / 10 ** DECIMALS, 'BVC');
console.log(`Explorer  : https://explorer.solana.com/tx/${sig}?cluster=devnet`);
