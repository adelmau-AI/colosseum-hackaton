/**
 * create-token.js
 * --------------------------------------------------------------------------
 * Creates the BitValue Coin (BVC) mint on Solana using Token-2022 + metadata.
 *
 * Design decisions (all reversible on devnet):
 * - Name / Symbol : BitValue Coin / BVC
 * - Decimals      : 6  (Solana uses u64 amounts; 18 decimals would cap supply ~18 tokens)
 * - Freeze auth   : none (drivers' tokens can never be frozen)
 * - Mint auth     : the server keypair (AUTHORITY_KEYPAIR)
 * - Metadata      : on-chain name + symbol via Token-2022 MetadataPointer extension
 *
 * The mint address is appended to .env as MINT_ADDRESS so later scripts can reuse it.
 * Re-running the script is a no-op if MINT_ADDRESS is already present.
 *
 * Usage:
 *   npm run create-token
 *   node scripts/create-token.js
 */

import 'dotenv/config';
import fs from 'fs';
import {
  Connection,
  Keypair,
  SystemProgram,
  Transaction,
  sendAndConfirmTransaction,
  LAMPORTS_PER_SOL,
} from '@solana/web3.js';
import {
  TOKEN_2022_PROGRAM_ID,
  ExtensionType,
  getMintLen,
  TYPE_SIZE,
  LENGTH_SIZE,
  createInitializeMetadataPointerInstruction,
  createInitializeMintInstruction,
} from '@solana/spl-token';
import {
  createInitializeInstruction,
  pack,
} from '@solana/spl-token-metadata';

// ---------------------------------------------------------------------------
// Guard: do not create a second mint by accident
// ---------------------------------------------------------------------------
if (process.env.MINT_ADDRESS) {
  console.log('Mint already exists:', process.env.MINT_ADDRESS);
  console.log(
    `https://explorer.solana.com/address/${process.env.MINT_ADDRESS}?cluster=devnet`
  );
  process.exit(0);
}

const conn = new Connection(process.env.RPC_URL, 'confirmed');
const payer = Keypair.fromSecretKey(
  Uint8Array.from(JSON.parse(fs.readFileSync(process.env.AUTHORITY_KEYPAIR, 'utf8')))
);

const balance = await conn.getBalance(payer.publicKey);
console.log('Authority balance:', balance / LAMPORTS_PER_SOL, 'SOL');
if (balance === 0) {
  console.error('No SOL. Request some at https://faucet.solana.com (Devnet)');
  process.exit(1);
}

// ---------------------------------------------------------------------------
// Token parameters
// ---------------------------------------------------------------------------
const DECIMALS = 6;
const mintKp = Keypair.generate();
const mint = mintKp.publicKey;

const metadata = {
  mint,
  name: 'BitValue Coin',
  symbol: 'BVC',
  uri: '', // set later with set-uri.js once the off-chain JSON is hosted
  additionalMetadata: [],
};

// ---------------------------------------------------------------------------
// Calculate rent-exempt lamports for mint account + metadata
// ---------------------------------------------------------------------------
const mintLen = getMintLen([ExtensionType.MetadataPointer]);
const metaLen = TYPE_SIZE + LENGTH_SIZE + pack(metadata).length;
const lamports = await conn.getMinimumBalanceForRentExemption(mintLen + metaLen);

// ---------------------------------------------------------------------------
// Build and send the creation transaction
// ---------------------------------------------------------------------------
const tx = new Transaction().add(
  // 1. Create the mint account
  SystemProgram.createAccount({
    fromPubkey: payer.publicKey,
    newAccountPubkey: mint,
    space: mintLen,
    lamports,
    programId: TOKEN_2022_PROGRAM_ID,
  }),
  // 2. Initialize MetadataPointer extension (points metadata to the mint itself)
  createInitializeMetadataPointerInstruction(
    mint,
    payer.publicKey,
    mint,
    TOKEN_2022_PROGRAM_ID
  ),
  // 3. Initialize the mint (decimals, mint authority, no freeze authority)
  createInitializeMintInstruction(
    mint,
    DECIMALS,
    payer.publicKey, // mint authority
    null,            // freeze authority = none
    TOKEN_2022_PROGRAM_ID
  ),
  // 4. Write name + symbol on-chain
  createInitializeInstruction({
    programId: TOKEN_2022_PROGRAM_ID,
    metadata: mint,
    updateAuthority: payer.publicKey,
    mint,
    mintAuthority: payer.publicKey,
    name: metadata.name,
    symbol: metadata.symbol,
    uri: metadata.uri,
  })
);

const sig = await sendAndConfirmTransaction(conn, tx, [payer, mintKp]);

// Persist mint address so the rest of the pipeline can use it
fs.appendFileSync('.env', `MINT_ADDRESS=${mint.toBase58()}\n`);

console.log('Token created successfully.');
console.log('Mint address :', mint.toBase58());
console.log('Tx signature :', sig);
console.log(
  `Explorer      : https://explorer.solana.com/address/${mint.toBase58()}?cluster=devnet`
);
