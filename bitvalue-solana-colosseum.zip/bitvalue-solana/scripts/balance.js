/**
 * balance.js
 * --------------------------------------------------------------------------
 * Prints the public key and SOL balance of the mint-authority wallet.
 *
 * Usage:
 *   npm run balance
 *   node scripts/balance.js
 */

import 'dotenv/config';
import fs from 'fs';
import {
  Connection,
  Keypair,
  LAMPORTS_PER_SOL,
} from '@solana/web3.js';

const conn = new Connection(process.env.RPC_URL, 'confirmed');
const kp = Keypair.fromSecretKey(
  Uint8Array.from(JSON.parse(fs.readFileSync(process.env.AUTHORITY_KEYPAIR, 'utf8')))
);

console.log('Address :', kp.publicKey.toBase58());
console.log('Balance :', (await conn.getBalance(kp.publicKey)) / LAMPORTS_PER_SOL, 'SOL');
